$(document).ready(function(){
	// $('.myElement').hover(function() {
	// 	this.style.backgroundColor = "crimson";
	// })

	$('.myElement').hover(function() {
		$(this).toggleClass('makeCrimson');
	})

	$('#stretchBox').click(function() {
		$('.myElement').slideToggle();
	})

	$('#stretchBox').text("something new");

});

