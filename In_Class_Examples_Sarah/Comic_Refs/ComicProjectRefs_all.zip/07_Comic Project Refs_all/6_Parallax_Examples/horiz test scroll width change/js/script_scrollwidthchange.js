

function reset() {
	console.log('in the onload');
	window.scrollTo(0,0);
	console.log(window.scrollX);
}


window.addEventListener('scroll', doPar);
let amount = 0;
let widthChange = 0;	//increases with scroll so can be applied to width of HTML element

//this starts tracking the change as soon as you start scrolling
// function doPar()
// {
//   console.log(window.scrollX);
//   widthChange = widthChange + (amount-window.scrollX);
//   console.log('width change is ' + widthChange);
//   if (widthChange > -450) {
//   	document.getElementById('width-container').style.width = 450 + widthChange + 'px';
//   } else {
//   	document.getElementById('width-container').style.width = '0px';
//   }
//   amount = window.scrollX;
// }

//this wait for a particular scrollX value then starts tracking the widthChange
function doPar()
{
  console.log(window.scrollX);
  
  if (window.scrollX > 1000) {
  	widthChange = widthChange + (amount-window.scrollX);
  	console.log('width change is ' + widthChange);
  	if (widthChange > -450) {
  		document.getElementById('width-container').style.width = 450 + widthChange + 'px';
  	} else {
  		document.getElementById('width-container').style.width = '0px';
  	}
  }
  amount = window.scrollX;
  
}

