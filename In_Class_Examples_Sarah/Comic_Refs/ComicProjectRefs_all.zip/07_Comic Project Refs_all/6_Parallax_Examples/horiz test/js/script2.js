

function reset() {
	console.log('in the onload');
	window.scrollTo(0,0);
	console.log(window.scrollX);
}

//this is simple and works well
function expand(){
	document.getElementById('parallax-container').style.width = "3500px"
}

