// window.addEventListener('scroll', doPar);

// function doPar()
// {
//   let parent =  document.getElementById('parallax-container');
//   let children = parent.getElementsByTagName('div');
//   for(let i = 0; i < children.length; i++) {
//     children[i].style.transform = 'translateY(-' + (window.pageYOffset *i / 9) + 'px)';
//     // console.log(window.pageYOffset * i / children.length + 'px');
//     console.log(window.pageYOffset);
//   }
// }

function reset() {
	console.log('in the onload');
	window.scrollTo(0,0);
	console.log(window.scrollX);
}

//test translate below

window.addEventListener('scroll', doPar);
let amount = 0;
let stopPoint = 1800;
let subtractWidthAmount = 0;
let startShrinkingAmount = 1100;

function doPar()
{
  // let bg =  document.getElementById('bg');
  // if (window.scrollX > amount) {
  // 	console.log('greater');
  // 	if (window.scrollX < stopPoint){
  // 		bg.style.transform = 'translateX(-' + amount + 'px)';
  // 	} else {
  // 		bg.style.transform = 'translateX(-' + stopPoint + 'px)';
  // 	}
  	
  // }
  console.log(window.scrollX);
  if (window.scrollX > 0){
    // subtractWidthAmount++
    // document.getElementById('ShrinkMe').style.width = 200 + subtractWidthAmount + 'px';
    //console.log (subtractWidthAmount);
    document.getElementById('red').style.transform = 'translateX(-' + amount + 'px)';
  }
  
  amount = window.scrollX;
}

