

function reset() {
	console.log('in the onload');
	window.scrollTo(0,0);
	console.log(window.scrollX);
}

//test translate below

window.addEventListener('scroll', doPar);
let amount = 0;

function doPar()
{
  console.log(window.scrollX);
  if (window.scrollX > 0){
    document.getElementById('red').style.transform = 'translateX(-' + window.scrollX + 'px)';
  }
  
  amount = window.scrollX;
}

