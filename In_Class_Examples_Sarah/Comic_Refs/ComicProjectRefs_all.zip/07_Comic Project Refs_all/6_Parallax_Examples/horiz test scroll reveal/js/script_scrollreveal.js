

function reset() {
	console.log('in the onload');
	window.scrollTo(0,0);
	// console.log(window.scrollX);
}

//test translate below

window.addEventListener('scroll', doPar);

function doPar()
{
  // console.log(window.scrollX);
  document.getElementById('red').style.transform = 'translateX(-' + window.scrollX + 'px)';
  
}

